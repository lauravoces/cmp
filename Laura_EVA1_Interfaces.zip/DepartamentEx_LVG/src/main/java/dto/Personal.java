/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

/**
 *
 * @author lavogra
 */
/**
 * Clase para registro de personal para examen de Desarrollo de Interfaces
 *
 * @author juandbp
 */
public class Personal {

    /**
     * Inicializa un objeto Personal con todas sus variables miembro
     *
     * @param nif NIF del personal
     * @param nombre Nombre del personal
     * @param apellidos Apellidos del personal
     * @param codigoDepartamento Código de departamento del personal
     * @param edad Edad del personal
     */
    public Personal(String nif, String nombre, String apellidos, String codigoDepartamento, int edad) {
        this.nif = nif;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.codDepartamento = codigoDepartamento;
        this.edad = edad;
    }

    /**
     * NIF
     */
    private String nif;

    /**
     * Nombre
     */
    private String nombre;

    /**
     * Apellidos
     */
    private String apellidos;

    /**
     * Edad
     */
    private int edad;
    /**
     * Código de departamento
     */
    private String codDepartamento;

    /**
     * Obtiene la edad del personal
     *
     * @return edad expresada como número entero
     */
    public int getEdad() {
        return edad;
    }

    /**
     * Ajusta la edad del personal
     *
     * @param edad Edad expresada como entero
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     * Obtiene el código de departamento del personal
     *
     * @return código de departamento
     */
    public String getCodDepartamento() {
        return codDepartamento;
    }

    /**
     * Ajusta el código de departamento del personal
     *
     * @param codDepartamento Código de departamento
     */
    public void setCodDepartamento(String codDepartamento) {
        this.codDepartamento = codDepartamento;
    }

    /**
     * Obtiene el NIF del personal
     *
     * @return NIF
     */
    public String getNif() {
        return nif;
    }

    /**
     * Ajusta el NIF del personal
     *
     * @param nif NIF
     */
    public void setNif(String nif) {
        this.nif = nif;
    }

    /**
     * Obtiene el nombre del personal
     *
     * @return nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Ajusta el nombre del personal
     *
     * @param nombre Nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene los apellidos del personal
     *
     * @return apellidos
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * Ajusta los apellidos del personal
     *
     * @param apellidos Apellidos
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

}
