/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package componente;

import dto.Personal;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author lavogra
 */
public class ListaPersonalTableModel extends AbstractTableModel{

      private List<Personal> lstPersonal;
    
    private String[] columnas={
        "NIF","Nombre","Apellido","C.Dept","edad"
    };

    /**
     *
     * @param listAero
     */
    public ListaPersonalTableModel (List<Personal>lstPersonal ){
        this.lstPersonal=lstPersonal;
    }
            
    /**
     *
     * @return
     */
    @Override
    public int getRowCount() {
        return lstPersonal.size();
    }

    /**
     *
     * @return
     */
    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    /**
     *
     * @param rowIndex
     * @param columnIndex
     * @return
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
       switch(columnIndex){
           case 0:
               return lstPersonal.get(rowIndex).getNif();
           case 1:
               return lstPersonal.get(rowIndex).getNombre();
           case 2:
                return lstPersonal.get(rowIndex).getApellidos();
           case 3:
                return lstPersonal.get(rowIndex).getCodDepartamento();
           case 4:
                 return lstPersonal.get(rowIndex).getEdad();
                       
        }
        return null;
    
    }

    /**
     *
     * @param column
     * @return
     */
    @Override
    public String getColumnName(int column) {
        return columnas[column];
    }
    
}
