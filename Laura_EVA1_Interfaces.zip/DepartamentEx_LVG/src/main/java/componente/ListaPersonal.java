/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package componente;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.io.Serializable;

/**
 *
 * @author lavogra
 */
public class ListaPersonal extends JPanel implements Serializable {

    private String codigo;
    private JTable table;
    private JTextField codigoTextField;
    private JLabel lblEdadMedia;

    /**
     *
     * @return
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     *
     * @param codigo
     */
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     *
     * @return
     */
    public JTable getTable() {
        return table;
    }

    /**
     *
     * @param table
     */
    public void setTable(JTable table) {
        this.table = table;
    }

    /**
     *
     * @return
     */
    public JTextField getCodigoTextField() {
        return codigoTextField;
    }

    /**
     *
     * @param codigoTextField
     */
    public void setCodigoTextField(JTextField codigoTextField) {
        this.codigoTextField = codigoTextField;
    }

    /**
     *
     */
    public ListaPersonal() {
        initComponents();

    }

    private void initComponents() {
        setLayout(new BorderLayout());

        ListaPersonalPanel listaPersonalPanel = new ListaPersonalPanel();

        table = listaPersonalPanel.getTblLP();

        codigoTextField = listaPersonalPanel.getLblCodigo();

        codigoTextField.setPreferredSize(new Dimension(150, codigoTextField.getPreferredSize().height));

        JButton filtrarButton = listaPersonalPanel.getBtnFiltro();
        filtrarButton.addActionListener(e -> filtrarPorCodigo(codigoTextField.getText()));
        JPanel filterPanel = new JPanel();
        filterPanel.add(new JLabel("Código:"));
        filterPanel.add(codigoTextField);
        filterPanel.add(filtrarButton);
        add(filterPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        lblEdadMedia = new JLabel("Edad media: ");
        add(lblEdadMedia, BorderLayout.SOUTH);
    }

    /**
     *
     * @param codigo
     */
    public void filtrarPorCodigo(String codigo) {
        ListaPersonalTableModel model = (ListaPersonalTableModel) table.getModel();
        TableRowSorter<ListaPersonalTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);
        RowFilter<Object, Object> filter = RowFilter.regexFilter("(?i)" + codigo, 3);
        sorter.setRowFilter(filter);
        edadMedia();
    }

    private void edadMedia() {
        int columnaAsumar = 4;
        int filas = table.getRowCount();
        double suma = 0.0;

        for (int i = 0; i < filas; i++) {
            Object valorCelda = table.getValueAt(i, columnaAsumar);
            if (valorCelda instanceof Number) {
                suma += ((Number) valorCelda).doubleValue();
            }
        }
        int media = (int) (suma / filas);
        lblEdadMedia.setText("Edad Media: "+String.valueOf(media));
    }

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Lista Personal");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add(new ListaPersonal());
            frame.setSize(400, 600);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
