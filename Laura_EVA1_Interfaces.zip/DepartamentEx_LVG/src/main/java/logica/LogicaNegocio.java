/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import dto.Personal;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lavogra
 */
/**
 * Clase soporte para lógica de negocio de examen de Desarrollo de Interfaces
 * @author Juan Diego Bueno
 */
public class LogicaNegocio {

    /**
     * Lista de personal
     */
    public static List<Personal> lstPersonal = new ArrayList<>();

    /**
     * Método de inicialización de variables
     */
    public static void initialize() {
        fillPersonal();
    }
     public static List<Personal> listaC() {
        fillPersonal();
        return lstPersonal;
    }
    /**
     * Llena la lista de personal con ejemplos de uso
     */
    private static void fillPersonal() {
        lstPersonal.add(new Personal("09769763D", "John", "Goodman", "INF", 53));
        lstPersonal.add(new Personal("09769764X", "Louise", "Stevenson", "INF", 52));
        lstPersonal.add(new Personal("09664141P", "Mary", "Shelley", "COC", 75));
        lstPersonal.add(new Personal("09807841D", "Óscar", "Adriá", "COC", 51));
        lstPersonal.add(new Personal("76435234F", "Benicio", "Del Toro", "INF", 56));
        lstPersonal.add(new Personal("71502672L", "Susan", "Sarandon", "ART", 77));
        lstPersonal.add(new Personal("09621532K", "Rose", "Nyland", "ART", 46));
        lstPersonal.add(new Personal("10215412J", "Jermaine", "Jackson", "ART", 46));
        lstPersonal.add(new Personal("45012423A", "Charlie", "Kaufman", "ART", 65));
    }
    
    
     public static double calcularEdadMedia(List<Personal> personas) {
        if (personas.isEmpty()) {
            return 0; 
        }

        int sumaEdades = 0;

        for (Personal persona : personas) {
            sumaEdades += persona.getEdad();
        }

        return (double) sumaEdades / personas.size();
    }
}
