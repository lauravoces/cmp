/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package myapplaura.departamentex_lvg;

/**
 *
 * @author lavogra
 */
public class DepartamentEx_LVG {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
